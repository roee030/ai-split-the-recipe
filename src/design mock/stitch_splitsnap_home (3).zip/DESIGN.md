# Design System Specification: The Human Ledger

## 1. Overview & Creative North Star
**Creative North Star: "The Editorial Archive"**

This design system rejects the cold, sterile nature of traditional financial tools in favor of a high-end, editorial experience. It treats the act of splitting a bill not as a mathematical chore, but as a social record—a "Human Ledger." 

The system breaks away from "template-style" layouts by embracing **Intentional Asymmetry**. We move beyond rigid, centered grids to use staggered layouts and varied content density. Large, expressive typography scales create a rhythmic hierarchy, while generous whitespace ensures that even the most complex receipt data feels airy and digestible. The aesthetic is one of "Warm Precision": the mathematical accuracy of a ledger paired with the tactile comfort of high-quality stationery.

---

## 2. Colors & Surface Philosophy
The palette is rooted in high-contrast sophistication, utilizing a creamy base to reduce eye strain and a deep navy for authoritative clarity.

### The "No-Line" Rule
**Borders are prohibited for sectioning.** To move beyond a "generic" UI, boundaries must be defined exclusively through background color shifts or tonal transitions. Use `surface-container-low` (#F5F3F0) to define a section against a `surface` (#FBF9F6) background. 

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine paper. 
- **Base Layer:** `surface` (#FBF9F6)
- **Secondary Content Area:** `surface-container-low` (#F5F3F0)
- **Interactive Cards:** `surface-container-lowest` (#FFFFFF)
By nesting a `surface-container-lowest` card inside a `surface-container-low` section, you create a natural, soft "lift" that feels premium and intentional without the need for structural lines.

### Signature Textures & Glass
- **The Gradient Soul:** For primary CTAs and hero headers, do not use flat colors. Use a subtle linear gradient transitioning from `primary` (#00000B) to `primary_container` (#1A1A2E) at a 135-degree angle.
- **Glassmorphism:** Floating action elements (like a "Scan Receipt" button) should use a semi-transparent `surface` color with a 12px `backdrop-blur`. This ensures the UI feels integrated and multi-dimensional.

---

## 3. Typography
We pair the tech-forward, geometric energy of **Sora** with the humanist clarity of **Plus Jakarta Sans**.

- **Display & Headline (Sora):** Used for "The Hook." Headlines should feel expressive and bold. Use `display-lg` (3.5rem) for total amounts and `headline-md` (1.75rem) for screen titles. The tight tracking of Sora adds a sense of modern "Brutalist" authority.
- **Title & Body (Plus Jakarta Sans):** Used for "The Detail." `title-md` (1.125rem) is the workhorse for item names in a list. It provides a sophisticated, readable contrast to the bold Sora headlines.
- **Labels (Inter):** Used for "The Metadata." `label-md` (0.75rem) in Inter provides the necessary precision for timestamps, tax calculations, and tiny footers.

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering** rather than traditional drop shadows.

- **The Layering Principle:** Avoid `elevation-1` shadows whenever possible. Instead, shift from `surface-container` to `surface-bright` to indicate a change in plane.
- **Ambient Shadows:** When an object must "float" (e.g., a modal or a primary FAB), use a custom shadow: `0px 24px 48px rgba(27, 28, 26, 0.06)`. This tinted, low-opacity shadow mimics natural light hitting a matte surface.
- **The "Ghost Border" Fallback:** If accessibility requires a stroke (e.g., in a high-glare environment), use `outline-variant` (#C8C2CD) at **15% opacity**. High-contrast, 100% opaque borders are strictly forbidden.

---

## 5. Components & Interaction Patterns

### Buttons
- **Primary:** Gradient-filled (`primary` to `primary_container`). Use `xl` (1.5rem / 24px) corner radius. Typography: Sora Bold.
- **Secondary (The "Claim" Action):** `secondary_container` (#FE6A34) with `on_secondary_container` text. This "Vibrant Persimmon" must be used sparingly to draw the eye to the most important social action.

### Cards & Lists
**Strict Rule: No Dividers.** To separate items in a receipt list:
1. Use `3.5` (1.2rem) spacing between items.
2. Use alternating background tints of `surface-container-low` and `surface` for very long lists.
3. Use a 16px (`xl`) border radius on all containers to maintain the "Human-Centric" approachability.

### The "Color-Fill" Claim Interaction
When a user claims an item, the background of the item card should transition from `surface` to the user's specific **Person Color** (e.g., Sage Green or Dusty Pink) using a 400ms ease-in-out liquid-fill animation. This provides an immediate, tactile sense of ownership.

### Inputs
Text fields should not have a bottom line or a full border. Use a filled style with `surface-container-high` (#EAE8E5) and a 16px top-rounded corner. On focus, the background shifts to `surface-container-highest` with a `secondary` (#AB3500) 2px bottom indicator.

---

## 6. Do's and Don'ts

### Do
- **Embrace Whitespace:** Use `spacing-8` (2.75rem) as a standard margin for screen edges to create an editorial feel.
- **Use Multi-Avatar Stacking:** When multiple people claim an item, stack their colored avatars with a 2px `surface` stroke between them.
- **Vary Type Weights:** Pair a `headline-lg` Sora Bold with a `body-md` Plus Jakarta Sans Regular for high-contrast information hierarchy.

### Don't
- **Don't use 1px solid borders:** This immediately cheapens the "Human Ledger" aesthetic. Use tonal shifts instead.
- **Don't use pure black:** Use `primary` (#00000B) or `on_surface` (#1B1C1A) to maintain the warmth of the "off-white and navy" theme.
- **Don't crowd the screen:** If a receipt has 40 items, use progressive disclosure or pagination. A "crowded" ledger is a failed ledger.